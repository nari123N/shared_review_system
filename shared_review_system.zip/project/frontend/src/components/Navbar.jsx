import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router";
import "./Navbar.css";

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const hiddenRoutes = ["/login", "/signup"];
  if (hiddenRoutes.includes(location.pathname)) return null;

  const handleLogout = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:4000/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });

      if (!response.ok) throw new Error("Logout failed");
      navigate("/login");
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <>
      <div className="hamburger" onClick={() => setIsOpen(!isOpen)}>
        {isOpen ? "✖" : "☰"}
      </div>

      <nav className={`sidebar ${isOpen ? "open" : ""}`}>
  <ul>
    {/* <li onClick={() => { navigate("/"); setIsOpen(false); }}>Home</li> */}
    <li onClick={() => {
  navigate("/", { state: { resetDashboard: true } });
  setIsOpen(false);
}}>Home</li>
    <li onClick={() => { navigate("/category"); setIsOpen(false); }}>Categories</li>
    <li onClick={() => { navigate("/profiles"); setIsOpen(false); }}>Profiles</li>
    <li onClick={() => { navigate("/chat"); setIsOpen(false); }}>Chat</li>
    <li onClick={() => { navigate("/Notifications"); setIsOpen(false); }}>Notifications</li>
    <li onClick={(e) => { handleLogout(e); setIsOpen(false); }}>Logout</li>
  </ul>
</nav>

    </>
  );
};

export default Navbar;
