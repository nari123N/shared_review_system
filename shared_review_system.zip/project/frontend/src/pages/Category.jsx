import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import "../css/category.css"; // ✅ Corrected path

// ✅ Import category images from css folder
import img1 from "../css/cat1.jpg";
import img2 from "../css/cat2.jpg";
import img3 from "../css/cat3.jpg";
import img4 from "../css/cat4.jpg";
import img5 from "../css/cat5.jpg";
import img6 from "../css/cat6.jpg";
import img7 from "../css/cat7.jpeg";

const Category = () => {
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("http://localhost:4000/Category");
        if (!response.ok) throw new Error("Failed to fetch categories");
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error("Error fetching categories:", error);
      }
    };

    fetchCategories();
  }, []);

  // ✅ Map category index to images
  const images = [img1, img2, img3, img4, img5, img6, img7];

  return (
    <div className="category-container">
      <h1 className="category-title">Categories</h1>
      <div className="category-grid">
        {categories.map((cat, index) => (
          <div key={cat.category_id} className="category-item">
            <img src={images[index % images.length]} alt={cat.name} />
            <button onClick={() => navigate(`/category/${cat.category_id}`)}>
              {cat.name}
            </button>
          </div>
        ))}
      </div>
      <div style={{ marginTop: "40px" }}>
        <button
          onClick={() => navigate('/dashboard')}
          style={{ padding: "10px 20px", fontSize: "16px" }}
        >
          ⬅ Back to Dashboard
        </button>
      </div>
    </div>
  );
};

export default Category;
