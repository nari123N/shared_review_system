import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import axios from "axios";
import { apiUrl } from "../config/config";
import img1 from "../css/img3.jpg";
import "../css/login.css";

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await axios.get(`${apiUrl}/isLoggedIn`, {
          withCredentials: true,
        });
        if (response.status === 200) {
          setLoggedIn(true);
          navigate("/dashboard");
        }
      } catch (err) {
        console.log("Not logged in yet:", err.response?.data);
      }
    };
    checkStatus();
  }, [navigate]);

  // Define the callback function globally
  useEffect(() => {
    window.handleGoogleResponse = async (response) => {
      try {
        const res = await fetch(`${apiUrl}/google-auth`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ token: response.credential }),
        });

        const data = await res.json();
        if (data.success) {
          navigate("/dashboard");
        } else {
          console.error("Google login failed:", data.message);
        }
      } catch (err) {
        console.error("Google login error:", err);
      }
    };
  }, [navigate]);

  // Render Google button once the script is available
  useEffect(() => {
    if (window.google && window.google.accounts && window.google.accounts.id) {
      window.google.accounts.id.initialize({
        client_id: "226426485757-bkm2dd6tful551ur1gphqoklgg9h5850.apps.googleusercontent.com",
        callback: window.handleGoogleResponse,
        ux_mode: "popup",
      });

      window.google.accounts.id.renderButton(
        document.getElementById("google-signin-btn"),
        {
          theme: "outline",
          size: "large",
        }
      );
    }
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        `${apiUrl}/login`,
        formData,
        {
          withCredentials: true,
          headers: { "Content-Type": "application/json" },
        }
      );
      setLoggedIn(true);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Error logging in!");
    }
  };

  return (
    <div
      className="login-container"
      style={{
        backgroundImage: `url(${img1})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="login-card">
        <h2>Sign In</h2>
        {error && <p style={{ color: "red" }}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Email"
            required
          />
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password"
            required
          />
          <button type="submit">Login</button>
        </form>
        <div style={{ marginTop: "10px" }}>
          <span className="link" onClick={() => navigate("/forgot-password")}>
            Forgot Password?
          </span>
        </div>


        <div style={{ marginTop: "1rem", textAlign: "center" }}>
          <p>Or sign in with your Google account</p>
          <div
            id="google-signin-btn"
            style={{ display: "flex", justifyContent: "center" }}
          ></div>
        </div>

        <div>
          Don't have an account?{" "}
          <div className="link" onClick={() => navigate("/signup")}>
            Sign up here
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
