import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { apiUrl } from "../config/config";
import img1 from "../css/img3.jpg";
import "../css/signup.css";

const VerificationForm = ({ email, onVerificationSuccess }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleVerify = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch(`${apiUrl}/verify-email`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, pin }),
      });

      const data = await response.json();
      if (response.ok) {
        onVerificationSuccess();
      } else {
        setError(data.message || 'Verification failed');
      }
    } catch (err) {
      setError('Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendPin = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${apiUrl}/resend-verification`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      if (response.ok) {
        alert('New verification PIN sent to your email!');
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError('Failed to resend PIN');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="verification-form-container">
      <h3>Email Verification</h3>
      <p>Please enter the verification PIN sent to {email}</p>
      {error && <div className="error">{error}</div>}
      <form onSubmit={handleVerify}>
        <input
          type="text"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          placeholder="Enter 6-digit PIN"
          maxLength="6"
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Verifying...' : 'Verify PIN'}
        </button>
      </form>
      <button 
        onClick={handleResendPin} 
        className="resend-button"
        disabled={loading}
      >
        Resend PIN
      </button>
    </div>
  );
};

const Signup = () => {
  const navigate = useNavigate();
  const [loggedIn, setLoggedIn] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState("");

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch(`${apiUrl}/isLoggedIn`, {
          method: "GET",
          credentials: "include",
        });

        if (!response.ok) {
          throw new Error("Not logged in");
        }

        const data = await response.json();
        console.log(data.message);
        navigate("/dashboard");
      } catch (err) {
        console.log(err);
      }
    };
    checkStatus();
  }, [navigate]);

  // Global Google callback
  useEffect(() => {
    window.handleGoogleResponse = async (response) => {
      try {
        const res = await fetch(`${apiUrl}/google-auth`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ token: response.credential }),
        });

        const data = await res.json();
        if (data.success) {
          navigate("/dashboard");
        } else {
          console.error("Google login failed:", data.message);
        }
      } catch (err) {
        console.error("Google login error:", err);
      }
    };
  }, [navigate]);

  // Load Google Sign-In button
  useEffect(() => {
    if (window.google && window.google.accounts && window.google.accounts.id) {
      window.google.accounts.id.initialize({
        client_id: "226426485757-bkm2dd6tful551ur1gphqoklgg9h5850.apps.googleusercontent.com",
        callback: window.handleGoogleResponse,
        ux_mode: "popup",
      });

      window.google.accounts.id.renderButton(
        document.getElementById("google-signup-btn"),
        {
          theme: "outline",
          size: "large",
        }
      );
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const response = await fetch(`${apiUrl}/signup`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setIsVerifying(true);
        setRegisteredEmail(formData.email);
      } else {
        setError(data.message || "Error signing up!");
      }
    } catch (err) {
      console.log(err);
      setError(`Error signing up!`);
    }
  };

  const handleVerificationSuccess = () => {
    navigate('/profiles?newUser=true');
  };

  return (
    <div
      className="login-container"
      style={{
        backgroundImage: `url(${img1})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div className="login-card">
        {!isVerifying ? (
          <>
            <h2>Sign Up</h2>
            {error && <p className="error">{error}</p>}
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
                placeholder="Username"
                required
              />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Email"
                required
              />
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Password"
                required
              />
              <button type="submit">Sign Up</button>
            </form>

            <div style={{ marginTop: "1rem", textAlign: "center" }}>
              <p>Or sign in with your Google account</p>
              <div
                id="google-signup-btn"
                style={{ display: "flex", justifyContent: "center" }}
              ></div>
            </div>

            <div>
              Already have an account?{" "}
              <div className="link" onClick={() => navigate("/login")}>
                Login here
              </div>
            </div>
          </>
        ) : (
          <VerificationForm
            email={registeredEmail}
            onVerificationSuccess={handleVerificationSuccess}
          />
        )}
      </div>
    </div>
  );
};

export default Signup;