import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router';
import '../css/UserProfile.css';

axios.defaults.withCredentials = true;

const UserProfile = () => {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [commentText, setCommentText] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);
  const [requestStatus, setRequestStatus] = useState({ status: 'initial', loading: false, error: null });
  const [isFollower, setIsFollower] = useState(false);
  const [removeFollowerStatus, setRemoveFollowerStatus] = useState({ loading: false, error: null });

  const baseUrl = 'http://localhost:4000';

  const normalizeProfilePic = (path) => {
    if (!path) return null;
    const normalized = path.replace('/uploads//uploads/', '/uploads/');
    return `${baseUrl}${normalized}`;
  };

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const loggedInResponse = await axios.get(`${baseUrl}/isLoggedIn`);
        const loggedInUserId = loggedInResponse.data.user_id;
        setCurrentUserId(loggedInUserId);

        const userResponse = await axios.get(`${baseUrl}/users/${userId}`);
        setUser({
          ...userResponse.data,
          profile_pic: normalizeProfilePic(userResponse.data.profile_pic),
        });

        const reviewsResponse = await axios.get(`${baseUrl}/users/${userId}/reviews`);
        setReviews(reviewsResponse.data);

        const statusResponse = await axios.get(`${baseUrl}/friends/status/${userId}`);
        const status = statusResponse.data.status === 'accepted' && statusResponse.data.direction === 'sent' ? 'following' :
                       statusResponse.data.status === 'pending' && statusResponse.data.direction === 'sent' ? 'sent' :
                       statusResponse.data.status === 'pending' && statusResponse.data.direction === 'received' ? 'pending_received' :
                       'initial';
        setRequestStatus({ status, loading: false, error: null });

        const followersResponse = await axios.get(`${baseUrl}/followers`);
        const followers = followersResponse.data;
        const isUserFollower = followers.some(follower => follower.user_id === parseInt(userId));
        setIsFollower(isUserFollower);

        setLoading(false);
      } catch (err) {
        console.error('Fetch error:', err.response?.status, err.response?.data);
        setError(err.response?.data?.message || 'Failed to load user profile');
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  const sendFriendRequest = async () => {
    setRequestStatus({ status: 'loading', loading: true, error: null });
    try {
      await axios.post(`${baseUrl}/friends/request`, { friendId: userId }, { withCredentials: true });
      setRequestStatus({ status: 'sent', loading: false, error: null });
    } catch (err) {
      console.error('Error sending friend request:', err.response?.data || err.message);
      setRequestStatus({ status: 'initial', loading: false, error: 'Failed to send request' });
    }
  };

  const unfollowUser = async () => {
    setRequestStatus({ status: 'loading', loading: true, error: null });
    try {
      await axios.post(`${baseUrl}/friends/unfollow`, { friendId: userId }, { withCredentials: true });

      // Re-fetch friend status
      const statusResponse = await axios.get(`${baseUrl}/friends/status/${userId}`);
      const status = statusResponse.data.status === 'accepted' && statusResponse.data.direction === 'sent' ? 'following' :
                     statusResponse.data.status === 'pending' && statusResponse.data.direction === 'sent' ? 'sent' :
                     statusResponse.data.status === 'pending' && statusResponse.data.direction === 'received' ? 'pending_received' :
                     'initial';
      setRequestStatus({ status, loading: false, error: null });

      // Re-fetch follower status
      const followersResponse = await axios.get(`${baseUrl}/followers`);
      const followers = followersResponse.data;
      const isUserFollower = followers.some(follower => follower.user_id === parseInt(userId));
      setIsFollower(isUserFollower);

      // Debug logs to verify state
      console.log('After unfollow - Request Status:', status);
      console.log('After unfollow - Is Follower:', isUserFollower);
      console.log('After unfollow - Followers:', followers);
    } catch (err) {
      console.error('Error unfollowing user:', err.response?.data || err.message);
      setRequestStatus({ status: 'following', loading: false, error: 'Failed to unfollow' });
    }
  };

  const removeFollower = async () => {
    setRemoveFollowerStatus({ loading: true, error: null });
    try {
      await axios.post(`${baseUrl}/friends/remove-follower`, { followerId: userId }, { withCredentials: true });
      setIsFollower(false);
      setRemoveFollowerStatus({ loading: false, error: null });
      alert('Follower removed successfully!');
    } catch (err) {
      console.error('Error removing follower:', err.response?.data || err.message);
      setRemoveFollowerStatus({ loading: false, error: 'Failed to remove follower' });
    }
  };

  const handleCommentSubmit = async (ratingId) => {
    const text = commentText[ratingId]?.trim();
    if (!text) {
      alert('Please enter a comment');
      return;
    }
    try {
      const response = await axios.post(`${baseUrl}/reviews/${ratingId}/comments`, {
        comment_text: text,
      }, {
        withCredentials: true,
      });

      const newComment = response.data.comment;
      setReviews((prev) =>
        prev.map((review) =>
          review.rating_id === ratingId
            ? {
                ...review,
                comments: [...(review.comments || []), newComment],
              }
            : review
        )
      );
      setCommentText((prev) => ({ ...prev, [ratingId]: '' }));
      alert('Comment added successfully!');
    } catch (err) {
      console.error('Comment submission error:', err.response?.data || err.message);
      alert('Error adding comment: ' + (err.response?.data?.message || 'Unknown error'));
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  const isDisabled = requestStatus.status === 'sent' || requestStatus.status === 'loading' || requestStatus.status === 'pending_received';
  const buttonText = requestStatus.status === 'loading'
    ? 'Processing...'
    : requestStatus.status === 'sent'
    ? 'Request Sent'
    : requestStatus.status === 'following'
    ? 'Unfollow'
    : requestStatus.status === 'pending_received'
    ? 'Request Received'
    : requestStatus.error
    ? 'Try Again'
    : 'Send Friend Request';
  const buttonClass = requestStatus.status === 'sent'
    ? 'request-sent-btn'
    : requestStatus.status === 'following'
    ? 'unfollow-btn'
    : requestStatus.status === 'pending_received'
    ? 'request-received-btn'
    : requestStatus.error
    ? 'friend-request-btn error'
    : 'friend-request-btn';
  const onClickHandler = requestStatus.status === 'following'
    ? unfollowUser
    : requestStatus.status === 'pending_received'
    ? () => navigate('/friend-requests')
    : requestStatus.error
    ? sendFriendRequest
    : sendFriendRequest;

  return (
    <div className="user-profile-container">
      <h1>{user.username}'s Profile</h1>
      <div className="user-profile-header">
        <img
          src={user.profile_pic || 'https://via.placeholder.com/150'}
          alt={user.username}
          className="user-profile-pic"
        />
        <div className="user-profile-info">
          <h2>{user.username}</h2>
          <p>{user.bio || 'No bio available'}</p>
          {currentUserId !== parseInt(userId) && (
            <div className="profile-buttons">
              <button
                onClick={onClickHandler}
                className={buttonClass}
                disabled={isDisabled}
              >
                {buttonText}
              </button>
              {requestStatus.error && <span className="error-message">{requestStatus.error}</span>}
              {isFollower && (
                <>
                  <button
                    onClick={removeFollower}
                    className={`remove-follower-btn ${removeFollowerStatus.loading ? 'loading' : ''}`}
                    disabled={removeFollowerStatus.loading}
                  >
                    {removeFollowerStatus.loading ? 'Processing...' : 'Remove Follower'}
                  </button>
                  {removeFollowerStatus.error && <span className="error-message">{removeFollowerStatus.error}</span>}
                </>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="user-reviews-section">
        <h2>Reviews</h2>
        {reviews.length === 0 ? (
          <p>No reviews yet</p>
        ) : (
          <ul className="reviews-list">
            {reviews.map((review) => (
              <li key={review.rating_id} className="review-item">
                <div className="review-header">
                  <img
                    src={review.item_image || 'https://via.placeholder.com/50'}
                    alt={review.item_title}
                    className="review-item-pic"
                  />
                  <div>
                    <h3>{review.item_title}</h3>
                    <p>Rating: {review.rating}/5</p>
                    <p>{review.review || 'No review text'}</p>
                  </div>
                </div>
                <div className="comments-section">
                  <h4>Comments</h4>
                  {review.comments && review.comments.length > 0 ? (
                    <ul className="comments-list">
                      {review.comments.map((comment) => (
                        <li key={comment.comment_id} className="comment-item">
                          <strong>{comment.username}</strong>: {comment.comment}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p>No comments yet</p>
                  )}
                  <textarea
                    value={commentText[review.rating_id] || ''}
                    onChange={(e) =>
                      setCommentText((prev) => ({ ...prev, [review.rating_id]: e.target.value }))
                    }
                    placeholder="Add a comment..."
                    className="comment-input"
                  />
                  <button
                    onClick={() => handleCommentSubmit(review.rating_id)}
                    className="comment-btn"
                  >
                    Comment
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div style={{ marginTop: '40px' }}>
        <button
          onClick={() => navigate('/profiles')}
          style={{ padding: '10px 20px', fontSize: '16px' }}
        >
          ⬅ Back to Profiles
        </button>
      </div>
    </div>
  );
};

export default UserProfile;