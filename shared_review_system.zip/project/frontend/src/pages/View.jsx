import React, { useEffect, useState } from "react";
import { useParams } from "react-router";

const View = () => {
  const { itemId } = useParams();
  const [item, setItem] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchItemDetails = async () => {
      try {
        const response = await fetch(`http://localhost:4000/items/${itemId}`);
        console.log("Fetch status:", response.status);
        if (!response.ok) throw new Error("Failed to fetch item details");
        const data = await response.json();
        console.log("Fetched item:", data);
        setItem(data);
      } catch (error) {
        console.error("Error fetching item:", error);
        setError("Failed to fetch item details");
      }
    };

    fetchItemDetails();
  }, [itemId]); // ✅ clean dependency array

  if (error) return <div>{error}</div>;
  if (!item) return <div>Loading...</div>;

  return (
    <div>
      <h1>{item.title}</h1>
      <img src={item.image_url} alt={item.title} style={{ width: "200px" }} />
      <p>{item.description}</p>
    </div>
  );
};

export default View;
